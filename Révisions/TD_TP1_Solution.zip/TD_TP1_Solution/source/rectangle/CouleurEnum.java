package fr.umontpellier.ha8403i.tp1.rectangle;

public enum CouleurEnum {
	ROUGE,
	VERT,
	BLEU
}
