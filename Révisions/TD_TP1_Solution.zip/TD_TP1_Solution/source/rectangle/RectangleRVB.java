package fr.umontpellier.ha8403i.tp1.rectangle;

public class RectangleRVB {
	/* ATTRIBUTES */
	int longueur; // cm
	int largeur; // cm
	Point2D position;
	Couleur couleur;
	
	/* STATIC CONSTANTS */
	public static final int NOMBRE_COTES = 4;
	public static final int ANGLE_COTES = 90; // en degrés
	
	/* METHODS */
	// derived attribute implemented as a method
	public int perimeter() {
		return 2 * (longueur + largeur);
	}
	
	// derived attribute implemented as a method
	public int aire() {
		return longueur * largeur;
	}
}
