package fr.umontpellier.ha8403i.tp1.rectangle;

public class Main {

	public static void main(String[] args) {
		/*
		 * Création et initialisation d'une instance de Rectangle
		 * ayant une couleur comme valeur énumérée
		 */
		System.out.println("Instance de Rectangle créée avec "
				+ "une couleur comme valeur énumérée");
		Rectangle r1 = new Rectangle();
		r1.longueur = 10;
		r1.largeur = 5;
		
		// Création et initialisation d'une instance de Point2D
		Point2D pt1 = new Point2D();
		pt1.x = 0;
		pt1.y = 0;
		
		// Affectation du point créé au rectangle créé
		r1.position = pt1;
		
		// Affichage des valeurs de l'instance créée
		System.out.println("Longueur : " + r1.longueur + " cm");
		System.out.println("Largeur : " + r1.largeur + " cm");
		System.out.println("Position : (" + r1.position.x + ", " + r1.position.y + ")");
		
		// Par défaut, couleur = VERT
		System.out.println("Couleur par défaut : " + r1.couleur);
		
		// Choisir une autre couleur pour le rectangle
		r1.couleur = CouleurEnum.BLEU;
		
		System.out.println("Couleur après changement : " + r1.couleur);
		System.out.println("Perimètre : " + r1.perimeter() + " cm");
		System.out.println("Aire : " + r1.aire() + " cm");
		
		/*
		 * Attributs statiques finaux de la classe Rectangle
		 * (accessibles par la classe directement, 
		 * sans besoin de passer par une instance de celle-ci)
		 */
		System.out.println("Nombre de côtés : " + Rectangle.NOMBRE_COTES);
		System.out.println("Angle entre côtés : " + Rectangle.ANGLE_COTES + " degrés");
		System.out.println();
		
		/*
		 * Création et initialisation d'une instance de RectangleRVB
		 * ayant une instance de Couleur comme attribut
		 */
		System.out.println("Instance de Rectangle créée avec une couleur RVB comme objet");
		RectangleRVB r2 = new RectangleRVB();
		r2.longueur = 20;
		r2.largeur = 10;
		
		// Création et initialisation d'une instance de Point2D
		Point2D pt2 = new Point2D();
		pt2.x = 5;
		pt2.y = 5;
		
		// Affectation du point créé au rectangle créé
		r2.position = pt2;
		
		// Affichage des valeurs de l'instance créée
		System.out.println("Longueur : " + r2.longueur + " cm");
		System.out.println("Largeur : " + r2.largeur + " cm");
		System.out.println("Position : (" + r2.position.x + ", " + r2.position.y + ")");
		
		// Création et initialisation d'une instance de Couleur
		Couleur couleur = new Couleur();
		couleur.rouge = 0;
		couleur.vert = 0;
		couleur.bleu = 255;
		
		// Affectation de la couleur créée au rectangle créé
		r2.couleur = couleur;
		System.out.println("Couleur : (" + r2.couleur.rouge + ", "
				+ r2.couleur.vert + ", " + r2.couleur.bleu + ")");
		System.out.println("Perimètre : " + r1.perimeter() + " cm");
		System.out.println("Aire : " + r1.aire() + " cm");
		
		/*
		 * Attributs statiques finaux de la classe RectangleRVB
		 * (accessibles par la classe directement, 
		 * sans besoin de passer par une instance de celle-ci)
		 */
		System.out.println("Nombre de côtés : " + RectangleRVB.NOMBRE_COTES);
		System.out.println("Angle entre côtés : " + RectangleRVB.ANGLE_COTES + " degrés");
	}
}
