package fr.umontpellier.ha8403i.tp1.rectangle;

public class Point2D {
	/* ATTRIBUTES */
	int x;
	int y;
}
