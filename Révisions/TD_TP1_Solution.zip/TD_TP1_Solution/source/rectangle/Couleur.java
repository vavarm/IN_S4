package fr.umontpellier.ha8403i.tp1.rectangle;

public class Couleur {
	/* ATTRIBUTES */
	int rouge;
	int vert;
	int bleu;
}
