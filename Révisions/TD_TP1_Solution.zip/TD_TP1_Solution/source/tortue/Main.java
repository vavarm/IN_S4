package fr.umontpellier.ha8403i.tp1.tortue;

public class Main {
	public static void main(String[] args) {
		/*
		 * Création et initialisation de deux instances d'habitats.
		 * Un habitat chaud et un autre très chaud
		 */
		Habitat h1 = new Habitat();
		h1.climat = "chaud";
		h1.temperature = 32.5;
		
		Habitat h2 = new Habitat();
		h2.climat = "très chaud";
		h2.temperature = 42;
		
		/*
		 * Création et initialisation d'une instance de l'espèce d'une tortue.
		 * Cette espèce peut vivre dans les deux habitats précédents
		 * possède un nom "tortue d'Herman" et une espérance de vie
		 * de 50 ans. En outre, elle peut manger des vers de terre
		 * et peut hiberner.
		 * Dans cet exemple, une tortue et ses parents 
		 * auront le même type d'espèce
		 */
		EspeceTortue tortueEspece = new EspeceTortue();
		tortueEspece.nom = "tortue d'Herman";
		tortueEspece.esperanceVie = 50;
		tortueEspece.nourriturePossible = "vers de terre";
		tortueEspece.hiberne = true;
		tortueEspece.habitatsPossibles = new Habitat[] {
			h1, h2	
		};
		
		/*
		 * Création et initialisation d'une tortue male
		 * d'espèce tortue d'Herman, âgée de 40 ans,
		 * et sans parents. Cette tortue habite actuellement
		 * dans un habitat chaud et est en hibernation.
		 * De plus, cette tortue servira comme père
		 * d'une autre tortue. 
		 */
		Tortue t1Pere = new Tortue();
		t1Pere.espece = tortueEspece;
		t1Pere.age = 40;
		t1Pere.genre = Genre.MALE;
		t1Pere.estEnHibernation = true;
		t1Pere.habitatActuel = h1; // climat chaud
		t1Pere.pere = null; // pas de père
		t1Pere.mere = null; // pas de mère
		
		/*
		 * Création et initialisation d'une tortue femelle
		 * d'espèce tortue d'Herman, âgée de 35 ans,
		 * et sans parents. Cette tortue habite actuellement
		 * dans un habitat très chaud, mais n'est pas en hibernation.
		 * De plus, cette tortue servira comme mère
		 * d'une autre tortue. 
		 */
		Tortue t1Mere = new Tortue();
		t1Mere.espece = tortueEspece;
		t1Mere.age = 35;
		t1Mere.genre = Genre.FEMALE;
		t1Mere.estEnHibernation = false;
		t1Mere.habitatActuel = h2; // climat très chaud
		t1Mere.pere = null; // pas de père
		t1Mere.mere = null; // pas de mère
		
		/*
		 * Création et initialisation d'une tortue femelle
		 * d'espèce tortue d'Herman, âgée de 20 ans,
		 * et ayant les deux tortues précédentes comme parents. 
		 * Cette tortue habite actuellement
		 * dans un habitat chaud, mais n'est pas en hibernation.
		 */
		Tortue t1 = new Tortue();
		t1.espece = tortueEspece;
		t1.age = 20;
		t1.genre = Genre.FEMALE;
		t1.estEnHibernation = false;
		t1.habitatActuel = h1; // climat chaud
		t1.pere = t1Pere; // admettant un père
		t1.mere = t1Mere; // admettant une mère
		
		displayTortue(t1);
	}
	
	private static void displayHabitat(Habitat habitat) {
		System.out.println("--------------------------");
		System.out.println("Habitat");
		System.out.println("Climat : " + 
				habitat.climat);
		System.out.println("Température : " + 
				habitat.temperature + " degrés Celsius");
		System.out.println("--------------------------");
	}
	
	// On suppose que l'espèce a uniquement deux habitats possibles
	private static void displayEspeceTortue(EspeceTortue espece) {
		System.out.println("##########################");
		System.out.println("Espèce Tortue");
		System.out.println("Nom : " + espece.nom);
		System.out.println("Espérance de vie : " + espece.esperanceVie);
		System.out.println("Nourriture possible : " + espece.nourriturePossible);
		System.out.println("Peut hiberner : " + espece.hiberne);
		System.out.println("Habitats possibles : ");
		displayHabitat(espece.habitatsPossibles[0]);
		displayHabitat(espece.habitatsPossibles[1]);
		System.out.println("##########################");
	}
	
	private static void displayTortue(Tortue tortue) {
		System.out.println("==========================");
		System.out.println("Tortue");
		displayEspeceTortue(tortue.espece); // affichage de l'espèce
		System.out.println("Age : " + tortue.age);
		System.out.println("Genre : " + tortue.genre);
		System.out.println("Est en hibernation : " + tortue.estEnHibernation);
		System.out.println("Habitat actuel :");
		displayHabitat(tortue.habitatActuel);
		
		// afficher le père uniquement s'il est disponible
		displayTortueParent(tortue.pere, "Père");
		
		// afficher la mère uniquement si elle est disponible
		displayTortueParent(tortue.mere, "Mère");
		System.out.println("==========================");
	}
	
	private static void displayTortueParent(Tortue parent, String which) {
		// afficher la parent uniquement s'il est disponible
		if(parent != null) {
			System.out.println(which + " :");
			displayTortue(parent);
		}
		else
			System.out.println(which + " : " + parent);
	}
}