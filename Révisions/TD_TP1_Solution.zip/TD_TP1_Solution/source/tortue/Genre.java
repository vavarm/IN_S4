package fr.umontpellier.ha8403i.tp1.tortue;

public enum Genre {
	MALE,
	FEMALE
}
