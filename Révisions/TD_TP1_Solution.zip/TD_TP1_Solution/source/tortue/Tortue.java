package fr.umontpellier.ha8403i.tp1.tortue;

public class Tortue {
	/* ATTRIBUTES */
	EspeceTortue espece;
	int age;
	Genre genre;
	boolean estEnHibernation; // true si la tortue est en hibernation, false sinon
	Habitat habitatActuel;
	Tortue pere;
	Tortue mere;
}
