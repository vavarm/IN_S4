package fr.umontpellier.ha8403i.tp1.tortue;

public class EspeceTortue {
	/* ATTRIBUTES */
	int esperanceVie;
	String nom;
	Habitat[] habitatsPossibles;
	String nourriturePossible;
	boolean hiberne; // true si l'espèce peut hiberner, false sinon
}
