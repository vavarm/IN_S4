package fr.umontpellier.ha8403i.tp1.tortue;

public class Habitat {
	/* ATTRIBUTES */
	String climat;
	double temperature; // en degrés Celsius
}
