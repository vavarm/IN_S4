package fr.umontpellier.ha8403i.tp2.etudiant;

public enum Nationalite {
	FRANCAIS,
	ETRANGER_FRANCOPHONE,
	ETRANGER_NON_FRANCOPHONE,
	INCONNU
}
