package fr.umontpellier.ha8403i.tp2.etudiant;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// création d'un étudiant avec une année de naissance
		System.out.println("Création d'un étudiant avec année de naissance");
		System.out.println("==============================================");
		EtudiantSansDate etudiant = new EtudiantSansDate(); 
		System.out.println("Avant la saisie :");
		System.out.println(etudiant); // étudiant avec valeurs par défaut
		
		// Saisie
		Scanner scan = new Scanner(System.in);
		etudiant.saisieAttributs(scan);
		System.out.println("Après la saisie :");
		System.out.println(etudiant); // étudiant avec les valeurs saisies
		System.out.println("==============================================");
		System.out.println();
		System.out.println();
		
		// création d'un étudiant avec une date de naissance
		System.out.println("Création d'un étudiant avec date de naissance");
		System.out.println("==============================================");
		Etudiant bachar = new Etudiant();
		System.out.println("Avant la saisie :");
		System.out.println(bachar); // étudiant avec valeurs par défaut
		
		// Saisie
		bachar.saisieAttributs(scan);
		System.out.println("Après la saisie :");
		System.out.println(bachar); // étudiant avec les valeurs saisies
		
		/*
		 * On ferme toujours le scanner une fois qu'on a terminé
		 * pour libérer la mémoire allouée au stream de l'entrée standard
		 * et qu'on n'utilise plus
		 */
		scan.close();
	}
}